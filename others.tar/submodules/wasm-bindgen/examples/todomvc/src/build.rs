extern crate askama;

fn main() {
    askama::rerun_if_templates_changed();
}
