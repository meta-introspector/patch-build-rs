fn main() {
    println!("cargo:rustc-cfg=backtrace_in_libstd");
}
